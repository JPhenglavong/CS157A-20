CREATE TABLE IF NOT EXISTS `genres` (
`id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB;


INSERT INTO `genres` (`id`, `name`) VALUES
(1, 'Rap'),
(2, 'Pop'),
(3, 'Country'),
(4, 'Electropop'),
(5, 'Dance-pop'),
(6, 'Korean Ballad'),
(7, 'Chinese Melodies'),
(8, 'KPop'),
(9, 'Rock'),
(10, 'Soul'),
(11, 'Vietnamese'),
(12, 'Thai'),
(13, 'Thai Rock'),
(14, 'Gangsta Rap'),
(15, 'R&B');










